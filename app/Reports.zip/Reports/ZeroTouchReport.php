<?php

namespace App\Reports;
require_once dirname(__FILE__)."/../../vendor/koolreport/core/autoload.php"; // No need, if you install KoolReport through composer
use koolreport\KoolReport;
use koolreport\processes\Group;
use koolreport\processes\Sort;

class ZeroTouchReport extends KoolReport
{
    protected $myData;

    public function settings()
    {
        // print_r($this->params);
        // die("===");
        return [
            'dataSources' => [
                'myData' => [
                    'class' => \koolreport\datasources\PdoDataSource::class,
                    'connectionString' => 'mysql:host=localhost;dbname=makesecurepro',
                    'username' => 'matrixemilocker',
                    'password' => 'Password@321',
                    'query' => function () {
                        return "SELECT coupon_id,user_name,user_phone,imei_no,date_of_purchase,coupon_parent_id,phone_status,mobile_name FROM `mobile_details` WHERE date(`date_of_purchase`) >= :start_date AND date(`date_of_purchase`) <= :end_date";
                    },
                    // 'params' => [
                    //     ':start_date' => $this->params['start_date'],
                    //     ':end_date' => $this->params['end_date'],
                    // ],
                ],
            ],
        ];
    }

    protected function setup()
    {
        $start_date = request('start_date');
        $end_date = request('end_date');
    
        // Define the SQL query with conditions
        $sql = "SELECT imei_no, mobile_name, date_of_purchase FROM `mobile_details` WHERE 1";
    
        if ($start_date) {
            $sql .= " AND date_of_purchase >= '$start_date'";
        }
    
        if ($end_date) {
            $sql .= " AND date_of_purchase <= '$end_date'";
        }
    
        $this->src("myData")
            ->query($sql)
            ->pipe($this->dataStore("zero_touch_data"));
    }
    
    
    protected function columns()
    {
        return [
            'imei_no' => 'Modem ID',
            'mobile_name' => 'Manufacturer',
            'date_of_purchase' => 'Date',
        ];
    }

    
    public function generateReport()
    {
        $data = $this->dataStore("myData")->getData();
        $this->dataStore("myData")->clear();
        $this->dataStore("myData")->setData($data);

        $this->dataStore("myData")
            ->pipe(new Filter(array(
                array("uses_or_unused", "=", "Used"),
            )))
            ->pipe(new Custom(function ($row) {
                $row['date_of_purchase'] = date('Y-m-d', strtotime($row['date_of_purchase']));
                return $row;
            }))
            ->pipe($this->dataStore("formatted_data"));

        $this->src("formatted_data")
            ->pipe($this->dataStore("result"));
    }
}
